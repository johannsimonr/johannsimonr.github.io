let geraet = document.getElementById("selectGer");
geraet.addEventListener("change", () => {
  let dasDiv = document.getElementById("einDiv" + geraet.value);
  let menge = document.getElementById("mengeGer");
  while (menge.lastChild) {
    menge.removeChild(menge.lastChild);
  }
  for (let i = 0; i < dasDiv.textContent; i++) {
    let eineOption = document.createElement("option");
    eineOption.value = i;
    eineOption.textContent = i + 1;
    menge.appendChild(eineOption);
  }

});
