class Kurs {
    constructor(kursname, lehrer, schuelerzahl, kursraum) {
        this.kursname = kursname;
        this.lehrer = lehrer;
        this.schuelerzahl = schuelerzahl;
        this.kursraum = kursraum;
    }
}


let bioQ1 = new Kurs("Biologie LK Q1", "Andreas Kleine-Finke", 14, "NW.03");
let musik8b = new Kurs("Musik 8b", "Martin Eibach", 28, "MU.1");
let mathe5a = new Kurs("Mathe 5a", "Eva Stegelmann", 29, "D.2.02");
let englischEF = new Kurs("Englisch EF", "Dietrich Neugebauer", 15, "D.1.01");
let latein8c = new Kurs("Latein 8c", "Brigitte Peukert", 24, "C.2.03");
let yogaAG = new Kurs("Yoga AG", "Annette Wolf", 16, "Spiegelsaal");


let kurse = [bioQ1, musik8b, mathe5a, englischEF, latein8c, yogaAG];


let neuerKurs = (kursname, lehrer, schuelerzahl, kursraum) => {
    kurse.push(new Kurs(kursname, lehrer, schuelerzahl, kursraum));
    console.log(kurse);
}


let datumsFormatierer = (datum) => {
    let ausgabe = "";
    let monat = datum.getMonth();
    let tag = datum.getDate();
    let jahr = datum.getFullYear();
    if (tag < 10) {
        ausgabe += "0" + tag;
    } else {
        ausgabe += "" + tag;
    }
    ausgabe += ".";
    if (monat < 10) {
        ausgabe += "0" + monat;
    } else {
        ausgabe += "" + monat;
    }
    ausgabe += "." + jahr;
    return ausgabe;
}

let zeitFormatierer = (zeit) => {
    let stunden = zeit.getHours();
    let minuten = zeit.getMinutes();
    let ausgabe = "";
    if (stunden < 10) {
        ausgabe += "0" + stunden;
    } else {
        ausgabe += "" + stunden;
    }
    if (minuten < 10) {
        ausgabe += ":0" + minuten;
    } else {
        ausgabe += ":" + minuten;
    }
    return ausgabe;
}



module.exports.kurse = kurse;
module.exports.neuerKurs = neuerKurs;
module.exports.datumsFormatierer = datumsFormatierer;
module.exports.zeitFormatierer = zeitFormatierer;
