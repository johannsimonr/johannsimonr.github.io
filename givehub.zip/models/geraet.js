class Geraet {
  constructor(
    typ,
    anschaffungsdatum,
    stueckzahl,
    marke,
    spezifikation,
    bilder = []
  ) {
    this.typ = typ;
    this.anschaffungsdatum = anschaffungsdatum;
    this.stueckzahl = stueckzahl;
    this.spezifikation = spezifikation;
    this.marke = marke;
    this.bilder = bilder;
    this.neuesBild = (bild) => {
      this.bilder.push(bild);
    };
  }
}

let ipad = new Geraet(
  "Tablet",
  new Date("2020-02-04"),
  15,
  "Apple",
  "iPad Air",
  ["../img/ipad.jpg"]
);
let laptop = new Geraet(
  "Laptop",
  new Date("2020-01-04"),
  20,
  "Lenovo",
  "ThinkPad T",
  ["../img/lenovo-laptop.png"]
);
let tablet = new Geraet(
  "Tablet",
  new Date("2020-04-01"),
  30,
  "Samsung",
  "Galaxy Tab S7+",
  ["../img/samsung-tablet.jpg"]
);

let ipad2 = new Geraet(
  "Tablet",
  new Date("2020-01-04"),
  5,
  "Apple",
  "iPad Pro",
  []
);

let laptop2 = new Geraet(
  "Laptop",
  new Date("2019-01-04"),
  19,
  "Lenovo",
  "ThinkPad X",
  []
);

let tablet2 = new Geraet(
  "Tablet",
  new Date("2018-04-03"),
  15,
  "Samsung",
  "Galaxy Tab S7",
  []
);

let geraete = [ipad, ipad2, laptop, laptop2, tablet, tablet2];

let neuesGeraet = (
  typ,
  anschaffungsdatum,
  stueckzahl,
  marke,
  spezifikation
) => {
  geraete.push(
    new Geraet(
      typ,
      new Date(anschaffungsdatum),
      new Number(stueckzahl),
      marke,
      spezifikation
    )
  );
};

module.exports.geraete = geraete;
module.exports.neuesGeraet = neuesGeraet;
