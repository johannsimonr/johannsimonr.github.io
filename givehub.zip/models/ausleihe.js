const geraete = require("./geraet.js");
const kurse = require("./kurs.js")

class ausleihe {
    constructor(ausleiher, beginn, ende, geraetetyp, menge, verwendungszweck, maengel) {
        this.ausleiher = ausleiher;
        this.beginn = beginn;
        this.ende = ende;
        this.geraetetyp = geraetetyp;
        this.menge = menge;
        this.verwendungszweck = verwendungszweck;
        this.maengel = maengel;
    }
}

let leihe1 = new ausleihe(kurse.kurse[0], new Date("2019-11-08T07:30:00"), new Date("2019-11-08T09:00:21"), geraete.geraete[1], 2, "Präsentationen", "2 Geräte sind beschmutzt");
let leihe2 = new ausleihe(kurse.kurse[1], new Date("2019-11-20T10:30:00"), new Date("2019-11-20T11:30:11"), geraete.geraete[0], 28, "Garage band", "2 Geräte sind beschmutzt");
let leihe3 = new ausleihe(kurse.kurse[2], new Date("2019-11-08T07:30:00"), new Date("2019-11-08T09:00:21"), geraete.geraete[2], 29, "geo gebra", "2 Geräte sind beschmutzt");
let leihe4 = new ausleihe(kurse.kurse[3], new Date("2020-11-08T07:30:00"), new Date("2020-11-08T09:00:00"), geraete.geraete[1], 1, "Verteidigung komplexe Leistung");
let leihe5 = new ausleihe(kurse.kurse[4], new Date("2021-01-04T10:30:00"), new Date("2021-01-04T12:00:00"), geraete.geraete[2], kurse.kurse[4].schuelerzahl, "Textübersetzungen");


let ausleihen = [leihe1, leihe2, leihe3, leihe4, leihe5];
let keyNamesAus = Object.keys(leihe1);

let addAusleihe = (ausleiher, beginn, ende, geraetetyp, menge, verwendungszweck, maengel)=>{
    ausleihen.push(new ausleihe(ausleiher, new Date(beginn), new Date(ende), geraetetyp, menge, verwendungszweck, maengel));
}

module.exports.ausleihen = ausleihen;
module.exports.keyNamesAus = keyNamesAus;
module.exports.addAusleihe = addAusleihe;