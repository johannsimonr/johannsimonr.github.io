const express = require("express");
const router = express.Router();
const multer = require("multer");
const ausleihen = require("../models/ausleihe");
const kurse = require("../models/kurs");
const geraete = require("../models/geraet");
const path = require("path");
const fs = require("fs");


var imageCount = 0;
var selectedIndex;

fs.rmdirSync(__dirname + "\\..\\public\\img\\tmp", { recursive: true });
const upload = multer({ dest: "public/img/tmp" });
router.post("/bildupload", upload.array("bild"), (req, res, next) => {
  var files = req.files;
  var falschesFormat = false;

  for (let file of files) {
    const tempPath = file.path;
    const extension = path.extname(file.originalname).toLocaleLowerCase();

    if (extension === ".png" || extension === ".jpg") {
      const imageName = "upload" + imageCount++ + extension;
      const targetPath = __dirname + "\\..\\public\\img\\tmp\\" + imageName;
      fs.rename(tempPath, targetPath, (err) => {
        if (!err) {
          geraete.geraete[selectedIndex].neuesBild(
            "..\\img\\tmp\\" + imageName
          );
        }
      });
    } else {
      falschesFormat = true;
    }
  }
  if (falschesFormat) {
    res
      .status(403)
      .contentType("text/plain")
      .end("Sorry, nur .png und .jpg erlaubt!");
  } else {
    res.redirect("/geraetedetails/" + selectedIndex);
  }
});

router.get("/geraeteliste", (req, res, next) => {
  selectedIndex = undefined;
  res.render("geraeteliste", { geraete: geraete.geraete });
});

router.use("/geraetedetails/", (req, res, next) => {
  let url = req.url;
  let index = url.charAt(url.length - 1);
  selectedIndex = index;
  res.render("geraetedetails", { geraet: geraete.geraete[index] });
});

router.post("/geraeteliste/neuesGeraet/", (req, res, next) => {
  let typ = req.body.typ;
  let anschaffungsdatum = req.body.anschaffungsdatum;
  let stueckzahl = req.body.stueckzahl;
  let marke = req.body.marke;
  let spezifikation = req.body.spezifikation;
  geraete.neuesGeraet(typ, anschaffungsdatum, stueckzahl, marke, spezifikation);
  res.redirect("/geraeteliste");
});

router.get("/geraeteliste/neuesGeraet/", (req, res, next) => {
  res.render("neuesGeraet");
});

router.get("/", (req, res, next) => {
  res.render("index");
});

router.use("/kursdetails/", (req, res, next) => {
  let url = req.url;
  let index = url.charAt(url.length - 1);
  selectedIndex = index;
  res.render("kursdetails", {
    kurs: kurse.kurse[index],
    ausleihen: ausleihen.ausleihen,
    datumsFormatierer: kurse.datumsFormatierer,
    zeitFormatierer: kurse.zeitFormatierer
  });
});

router.post("/kursliste/neuerKurs", (req, res, next) => {
  let name = req.body.kursname;
  let lehrer = req.body.lehrer;
  let zahl = req.body.schuelerzahl;
  let kursraum = req.body.kursraum;
  kurse.neuerKurs(name, lehrer, zahl, kursraum);
  res.redirect("/kursliste");
})
router.get("/kursliste/neuerKurs", (req, res, next) => {
  res.render("neuerKurs");
});

router.get("/kursliste", (req, res, next) => {
  selectedIndex = undefined;
  res.render("kursliste", { kurse: kurse.kurse });
});

router.use("/neueAusleihe", (req, res, next) => {
  res.render("neueAusleihe");
});

router.post("/ausleihliste/neueAusleihe", (req, res, next) => {
  let ausleiher = kurse.kurse[req.body.ausleiher];
  let beginn = req.body.beginn;
  let ende = req.body.ende;
  let geraetetyp = geraete.geraete[req.body.geraetetyp];
  let menge = req.body.menge;
  let verwendungszweck = req.body.verwendungszweck;
  let maengel = req.body.maengel;
  ausleihen.addAusleihe(
    ausleiher,
    beginn,
    ende,
    geraetetyp,
    menge,
    verwendungszweck,
    maengel
  );
  res.redirect("/ausleihliste");
});

router.get("/ausleihliste/neueAusleihe", (req, res, next) => {
  res.render("neueAusleihe", {
    kurse: kurse.kurse,
    geraete: geraete.geraete,
    selectedIndex: selectedIndex
  });
});

router.get("/ausleihliste", (req, res, next) => {
  selectedIndex = undefined;
  res.render("ausleihliste", { ausleihen: ausleihen.ausleihen });
});

router.use("/ausleihedetails/", (req, res, next) => {
  let url = req.url;
  let index = url.charAt(url.length - 1);
  res.render("ausleihedetails", {
    ausleihe: ausleihen.ausleihen[index],
  });
});

module.exports = router;
